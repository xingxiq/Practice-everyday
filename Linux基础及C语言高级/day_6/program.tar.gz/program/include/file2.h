void func2();
