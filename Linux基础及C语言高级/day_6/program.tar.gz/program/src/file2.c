#include <stdio.h>

void func2()
{
    printf("hello world\n");
}
