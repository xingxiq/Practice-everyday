#include <file1.h>

int main()
{
    func1();

    return 0;
}

