#include <file2.h>

void func1()
{
    func2();
}
