#include "link_stack.h"

//创建数据节点
node_t *create_data_node(DATA_TYPE insert_data){
	node_t *ptemp = (node_t*)malloc(sizeof(node_t));
	if(NULL == ptemp){
		printf("%s(%d):%s\n",__FILE__,__LINE__,"malloc error");
		exit(-1);
	}
	memset(ptemp,0,sizeof(node_t));
	ptemp->data = insert_data;
	ptemp->next = NULL;
	return ptemp;
}

//创建栈
stack_t *create_stack(){
	stack_t *ptemp = (stack_t*)malloc(sizeof(stack_t));
	if(NULL == ptemp){
		printf("%s(%d):%s\n",__FILE__,__LINE__,"malloc error");
		exit(-1);
	}
	memset(ptemp,0,sizeof(stack_t));
	ptemp->top = NULL;
	return ptemp;
}

//入栈
int push_stack(stack_t *my_stack,DATA_TYPE data){
	if(NULL == my_stack){
		printf("%s(%d):%s\n",__FILE__,__LINE__,"入参为NULL，请检查入参");
		return -1;
	}
	node_t *pnew = create_data_node(data);	
	pnew->next = my_stack->top;
	my_stack->top = pnew;
	my_stack->lenth++;
}

//判断栈是否为空
int stack_is_empty(stack_t *my_stack){
	if(NULL == my_stack){
		printf("%s(%d):%s\n",__FILE__,__LINE__,"入参为NULL，请检查入参");
		return -1;
	}
	return (my_stack->lenth == 0) ? 0 : 1;
	//返回 0 代表栈空
	//返回 1 代表栈非空
}

//出栈（弹栈）
int pop_stack(stack_t *my_stack,DATA_TYPE *value){
	if(NULL == my_stack){
		printf("%s(%d):%s\n",__FILE__,__LINE__,"入参为NULL，请检查入参");
		return -1;
	}
	if( 0 == stack_is_empty(my_stack)){
		printf("%s(%d):%s\n",__FILE__,__LINE__,"栈为空，弹栈失败");
		return -1;
	}
	*value = my_stack->top->data;
	node_t *pdel = my_stack->top;
	my_stack->top = my_stack->top->next;
	free(pdel);
	pdel = NULL;
	my_stack->lenth--;
}

int destroy_stack(stack_t *my_stack){
	if(NULL == my_stack){
		printf("%s(%d):%s\n",__FILE__,__LINE__,"入参为NULL，请检查入参");
		return -1;
	}
	node_t *ptemp = my_stack->top;
	node_t *pdel = NULL;
	while(NULL != ptemp){
		pdel = ptemp;
		ptemp = ptemp->next;
		free(pdel);
		pdel = NULL;
	}
	free(my_stack);
}

//遍历栈  ----非必要函数，测试使用
int print_stack(stack_t *my_stack){
	if(NULL == my_stack){
		printf("%s(%d):%s\n",__FILE__,__LINE__,"入参为NULL，请检查入参");
		return -1;
	}
	node_t *ptemp = my_stack->top;
	while(NULL != ptemp){
		printf("%d  ",ptemp->data);
		ptemp = ptemp->next;
	}
	printf("\n");
}







