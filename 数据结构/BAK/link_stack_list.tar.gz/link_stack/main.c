#include "link_stack.h"

int main(){
	stack_t *my_stack = create_stack();
	push_stack(my_stack, 10);
	push_stack(my_stack, 20);
	push_stack(my_stack, 30);
	push_stack(my_stack, 40);
	print_stack(my_stack);

	int value = -1;
	pop_stack(my_stack,&value);
	pop_stack(my_stack,&value);
	push_stack(my_stack, 60);
	push_stack(my_stack, 70);

	print_stack(my_stack);
	destroy_stack(my_stack);
	my_stack=NULL;
	return 0;
}

