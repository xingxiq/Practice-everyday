#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define DATA_TYPE int
#define MAX 5
typedef struct __STACK{
	DATA_TYPE data[MAX];
	int top;
}stack_t;

int create_stack(stack_t **);
int destroy_stack(stack_t **);
int push_stack(stack_t*,DATA_TYPE);
int stack_is_full(stack_t*);
int stack_is_empty(stack_t*);
int print_stack(stack_t*);
int pop_stack(stack_t*,DATA_TYPE*);
