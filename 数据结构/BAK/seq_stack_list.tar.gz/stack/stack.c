#include "stack.h"
//创建栈
int create_stack(stack_t **my_stack){
	*my_stack = (stack_t*)malloc(sizeof(stack_t));
	if(NULL == *my_stack){
		printf("%s(%d):%s\n",__FILE__,__LINE__,"malloc error");
		exit(-1);
	}
	memset(*my_stack,0,sizeof(stack_t));
}
//判断栈是否 满
int stack_is_full(stack_t *my_stack){
	if(NULL == my_stack){
		printf("%s(%d):%s\n",__FILE__,__LINE__,"入参为空,请检查");
		return -1;//-1  调用出错
	}
	if(my_stack->top == MAX){
		printf("%s(%d):%s\n",__FILE__,__LINE__,"栈已经满了");
		return 0;//0 代表栈满
	}
	return 1;//1  代表栈未满
}
//判断栈是否空
int stack_is_empty(stack_t *my_stack){
	if(NULL == my_stack){
		printf("%s(%d):%s\n",__FILE__,__LINE__,"入参为空,请检查");
		return -1;//-1  调用出错
	}
	if(my_stack->top == 0){
		printf("%s(%d):%s\n",__FILE__,__LINE__,"栈为空");
		return 0;//0 代表栈空
	}
	return 1;//1  代表栈非空

}
//入栈
int push_stack(stack_t *my_stack,DATA_TYPE value){
	if(NULL == my_stack){
		printf("%s(%d):%s\n",__FILE__,__LINE__,"入参为空,请检查");
		return -1;
	}
	if(0 == stack_is_full(my_stack)){
		return -1;
	}
	my_stack->data[my_stack->top] = value;
	my_stack->top++;
}


//销毁栈
int destroy_stack(stack_t **my_stack){
	free(*my_stack);
	*my_stack = NULL;
}

//出栈--弹栈   (取出元素值后删除数据元素)
int pop_stack(stack_t *my_stack,DATA_TYPE *value){
	if(NULL == my_stack){
		printf("%s(%d):%s\n",__FILE__,__LINE__,"入参为空,请检查");
		return -1;
	}
	if(0 == stack_is_empty(my_stack)){
		return -1;
	}
	*value = my_stack->data[my_stack->top - 1];
	my_stack->top--;
}

//遍历栈中元素 --- 为了验证现象的
int print_stack(stack_t *my_stack){
	if(NULL == my_stack){
		printf("%s(%d):%s\n",__FILE__,__LINE__,"入参为空,请检查");
		return -1;
	}
	if(0 == stack_is_empty(my_stack)){
		return -1;
	}
	int i = 0;
	for(i = 0; i < my_stack->top; i++){
		printf("%d  ",my_stack->data[i]);
	}
	printf("\n");
}
