#include "stack.h"

int main(){
	stack_t *my_stack = NULL;
	create_stack(&my_stack);

	push_stack(my_stack,10);
	push_stack(my_stack,20);
	push_stack(my_stack,30);
	push_stack(my_stack,40);
	push_stack(my_stack,50);
	push_stack(my_stack,60);
	print_stack(my_stack);
	
	DATA_TYPE value;
	int i;
	for(i=0;i<3;i++){
		pop_stack(my_stack,&value);
		printf("出栈的元素为 : %d\n",value);
	}
	print_stack(my_stack);
	printf("----------------------------\n");
	push_stack(my_stack,10);
	push_stack(my_stack,20);
	push_stack(my_stack,30);
	push_stack(my_stack,40);
	push_stack(my_stack,10);
	pop_stack(my_stack,&value);
	printf("出栈的元素为 : %d\n",value);
	print_stack(my_stack);
	for(i=0;i<6;i++){
		pop_stack(my_stack,&value);
	}
	print_stack(my_stack);

	destroy_stack(&my_stack);
	return 0;
}
