#include "seq_queue.h"
//创建队列
queue_t *create_queue(){
	queue_t *ptemp = (queue_t*)malloc(sizeof(queue_t));
	if(NULL == ptemp){
		printf("%s(%d):%s\n",__FILE__,__LINE__,"malloc error");
		exit(-1);
	}
	memset(ptemp,0,sizeof(queue_t));
	return ptemp;
}

//判断队列是否已满
int queue_is_full(queue_t *my_queue){
	if(NULL == my_queue){
		printf("%s(%d):%s\n",__FILE__,__LINE__,"入参为NULL，请检查");
		return -1;
	}
	return ((my_queue->rear + 1) % MAX == my_queue->front)? 0 : 1;
	//返回0 代表 队列已经满了
}

//向队列中插入数据
int insert_queue(queue_t *my_queue,DATA_TYPE insert_data){
	if(NULL == my_queue){
		printf("%s(%d):%s\n",__FILE__,__LINE__,"入参为NULL，请检查");
		return -1;
	}
	if(0 == queue_is_full(my_queue)){
		printf("%s(%d):%s\n",__FILE__,__LINE__,"队列已经满,插入失败");
		return -1;
	}
	my_queue->data[my_queue->rear % MAX] = insert_data;
	my_queue->rear++;
}
//判断队列中是否有数据
int queue_is_empty(queue_t *my_queue){
	if(NULL == my_queue){
		printf("%s(%d):%s\n",__FILE__,__LINE__,"入参为NULL，请检查");
		return -1;
	}
	return my_queue->front == my_queue->rear?0:1;
	//返回0 代表队列为空
}

//在队列中取出数据
int get_data_from_queue(queue_t *my_queue,DATA_TYPE *value){
	if(NULL == my_queue){
		printf("%s(%d):%s\n",__FILE__,__LINE__,"入参为NULL，请检查");
		return -1;
	}
	if(0 == queue_is_empty(my_queue)){
		printf("%s(%d):%s\n",__FILE__,__LINE__,"队列为空，出队列失败");
		return -1;
	}
	*value = my_queue->data[my_queue->front%MAX];
	my_queue->front++;
}


//遍历队列
int print_queue(queue_t *my_queue){
	if(NULL == my_queue){
		printf("%s(%d):%s\n",__FILE__,__LINE__,"入参为NULL，请检查");
		return -1;
	}
	int i = 0;
	for(i = my_queue->front; i < my_queue->rear; i++){
		printf("%d  ",my_queue->data[i%MAX]);
	}
	printf("\n");
}

//销毁队列
int destroy_queue(queue_t *my_queue){
	if(NULL == my_queue){
		printf("%s(%d):%s\n",__FILE__,__LINE__,"入参为NULL，请检查");
		return -1;
	}
	free(my_queue);
}
