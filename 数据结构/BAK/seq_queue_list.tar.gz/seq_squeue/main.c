#include "seq_queue.h"

int main(){
	queue_t *my_queue = create_queue();
	insert_queue(my_queue, 10);
	insert_queue(my_queue, 20);
	insert_queue(my_queue, 30);
	print_queue(my_queue);

	DATA_TYPE value = -1;
	get_data_from_queue(my_queue, &value);
	get_data_from_queue(my_queue, &value);
printf("--------------------------------\n");
	insert_queue(my_queue, 10);
	insert_queue(my_queue, 40);
	print_queue(my_queue);

	destroy_queue(my_queue);
	my_queue = NULL;
	return 0;
}
