#include "sequence.h"
//创建顺序表
seq_list *create_seq_list(){
	seq_list *ptemp = (seq_list*)malloc(sizeof(seq_list));
	if(NULL == ptemp){
		printf("%s(%d):%s\n",__FILE__,__LINE__,"malloc error");
		exit(-1);//程序退出
	}
	//初始化为 0
	memset(ptemp,0,sizeof(seq_list));
	return ptemp;
}
//如果采用传参的方式申请空间,要注意值传递和地址传递的问题
int create_list2(seq_list **p){
	*p = (seq_list*)malloc(sizeof(seq_list));
	if(NULL == *p){
		printf("%s(%d):%s\n",__FILE__,__LINE__,"malloc error");
		exit(-1);//程序退出
	}
}

//按位置插入数据
int insert_seq_list(seq_list* my_list,int pos,DATA_TYPE insert_data){
	if(NULL == my_list){
		printf("%s(%d):%s\n",__FILE__,__LINE__,"入参为NULL，请检查");
		exit(-1);//程序退出
	}
	if(my_list->lenth == MAX){
		printf("%s(%d):%s\n",__FILE__,__LINE__,"表满，插入失败");
		return -1;//函数返回调用处
	}
	if(pos < 0 || pos > my_list->lenth){
		printf("%s(%d):%s\n",__FILE__,__LINE__,"插入位置不合理，插入失败");
		return -1;//函数返回调用处
	}
	int i = 0;
	for(i=my_list->lenth; i>pos; i--){
		my_list->data[i] = my_list->data[i-1];
	}
	my_list->data[pos] = insert_data;
}


//释放顺序表
int release_seq_list(seq_list *p){
	free(p);
}
